<?php

use App\Http\Controllers\ProfileController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\LandingController;
use App\Http\Controllers\FormulirController;
use App\Http\Controllers\DataPendaftarController;
use App\Http\Controllers\Admin\PendaftarController;
use App\Http\Controllers\Student\PendaftaranController;
use App\Http\Controllers\Student\StatusController;
use Illuminate\Support\Facades\Route;

// Landing page
Route::get('/', [LandingController::class, 'index'])->name('landing');

// Dashboard dispatcher
Route::get('/dashboard', [DashboardController::class, 'index'])
    ->middleware(['auth', 'verified'])
    ->name('dashboard');

// Admin routes
Route::middleware(['auth', 'admin'])->prefix('admin')->name('admin.')->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'admin'])->name('dashboard');
    Route::get('/pendaftar', [PendaftarController::class, 'index'])->name('pendaftar.index');
    Route::get('/pendaftar/{id}', [PendaftarController::class, 'show'])->name('pendaftar.show');
    Route::post('/pendaftar/{id}/verify', [PendaftarController::class, 'verify'])->name('pendaftar.verify');
});

// Student routes
Route::middleware(['auth', 'student'])->prefix('student')->name('student.')->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'student'])->name('dashboard');

    // Pendaftaran routes
    Route::get('/pendaftaran', [PendaftaranController::class, 'index'])->name('pendaftaran.index');
    Route::post('/pendaftaran', [PendaftaranController::class, 'store'])->name('pendaftaran.store');

    // Status routes
    Route::get('/status', [StatusController::class, 'index'])->name('status.index');
});

// Legacy routes (untuk backward compatibility)
Route::middleware(['auth', 'student'])->group(function () {
    Route::get('/student/formulir-pendaftaran', [FormulirController::class, 'index'])->name('student.formulir-pendaftaran');
    Route::post('/student/formulir-pendaftaran', [FormulirController::class, 'store'])->name('student.formulir-pendaftaran.store');
    Route::get('/student/kelola-data-pendaftar', [DataPendaftarController::class, 'index'])->name('student.kelola-data-pendaftar');
});

// Profile routes
Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__ . '/auth.php';
