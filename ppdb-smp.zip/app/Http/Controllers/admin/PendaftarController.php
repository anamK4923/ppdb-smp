<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\LogAktivitas;
use App\Models\Pendaftaran;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PendaftarController extends Controller
{
    public function index(Request $request)
    {
        $query = Pendaftaran::with('user');

        // Filter berdasarkan nama
        if ($request->filled('nama')) {
            $query->where('nama', 'like', '%' . $request->nama . '%');
        }

        // Filter berdasarkan status verifikasi
        if ($request->filled('status_verifikasi')) {
            $query->where('status_verifikasi', $request->status_verifikasi);
        }

        // Filter berdasarkan status seleksi
        if ($request->filled('status_seleksi')) {
            $query->where('status_seleksi', $request->status_seleksi);
        }

        // Filter berdasarkan tanggal pendaftaran
        if ($request->filled('tanggal_dari')) {
            $query->whereDate('created_at', '>=', $request->tanggal_dari);
        }

        if ($request->filled('tanggal_sampai')) {
            $query->whereDate('created_at', '<=', $request->tanggal_sampai);
        }

        $pendaftars = $query->latest()->paginate(10);

        // Statistik untuk cards
        $stats = [
            'total' => Pendaftaran::count(),
            'terverifikasi' => Pendaftaran::where('status_verifikasi', 'Terverifikasi')->count(),
            'belum_verifikasi' => Pendaftaran::where('status_verifikasi', 'Belum Diverifikasi')->count(),
            'ditolak' => Pendaftaran::where('status_verifikasi', 'Ditolak')->count(),
        ];

        return view('admin.pendaftar.index', compact('pendaftars', 'stats'));
    }

    public function show($id)
    {
        $pendaftar = Pendaftaran::with('user')->findOrFail($id);
        return view('admin.pendaftar.show', compact('pendaftar'));
    }

    public function verifikasi(Request $request, $id)
    {
        $request->validate([
            'status_verifikasi' => 'required|in:Terverifikasi,Ditolak',
            'status_seleksi'    => 'nullable|in:Diterima,Tidak Diterima,Belum Diumumkan',
            'catatan' => 'nullable|string|max:500'
        ]);

        $pendaftar = Pendaftaran::findOrFail($id);
        $pendaftar->update([
            'status_verifikasi' => $request->status_verifikasi,
            'status_seleksi'    => $request->status_seleksi ?? $pendaftar->status_seleksi,
        ]);

        // Simpan log aktivitas
        LogAktivitas::create([
            'user_id'    => Auth::id(),
            'aktivitas'  => 'Verifikasi',
            'keterangan' => 'Verifikasi pendaftar: ' . $pendaftar->nama . ' - Status: ' . $request->status_verifikasi,
            'waktu'      => now(),
        ]);

        return redirect()->route('admin.pendaftar.index')->with('success', 'Pendaftaran berhasil diverifikasi.');
    }

    public function destroy($id)
    {
        $pendaftar = Pendaftaran::findOrFail($id);
        $nama = $pendaftar->nama;
        $pendaftar->delete();

        // Simpan log
        LogAktivitas::create([
            'user_id'    => Auth::id(),
            'aktivitas'  => 'Hapus Pendaftaran',
            'keterangan' => 'Hapus data pendaftar: ' . $nama,
            'waktu'      => now(),
        ]);

        return redirect()->route('admin.pendaftar.index')->with('success', 'Data pendaftar berhasil dihapus.');
    }
}
